document.addEventListener('DOMContentLoaded', function() {
    const workoutOptions = document.getElementById('workout-options');
    const todoList = document.getElementById('todo-list');
    const saveButton = document.getElementById('save-button');

    workoutOptions.addEventListener('change', function() {
        const selectedWorkout = workoutOptions.value;
        populateTodoList(selectedWorkout);
    });
    

    todoList.addEventListener('change', function(event) {
        if (event.target.type === 'checkbox') {
            const listItem = event.target.closest('li');
            if (event.target.checked) {
                listItem.classList.add('checked');
                todoList.appendChild(listItem);
            } else {
                listItem.classList.remove('checked');
                todoList.prepend(listItem);
            }
        }
    });

    function populateTodoList(workout) {
        // Clear existing items
        todoList.innerHTML = '';

        // Populate the to-do list based on the selected workout
        switch (workout) {
            case 'rest-day':
                addTodoItem('Relax and recover');
                break;
            case 'leg-day':
                addTodoItem('Squats');
                addTodoItem('Leg Press');
                addTodoItem('Lunges');
                addTodoItem('Leg Curls');
                addTodoItem('Calf Raises');
                break;
            case 'chest-day':
                addTodoItem('Bench Press');
                addTodoItem('Dumbbell Flyes');
                addTodoItem('Incline Press');
                addTodoItem('Chest Dips');
                break;
            case 'back-day':
                addTodoItem('Deadlifts');
                addTodoItem('Pull-Ups');
                addTodoItem('Bent Over Rows');
                addTodoItem('Lat Pulldowns');
                break;
            case 'shoulder-day':
                addTodoItem('Overhead Press');
                addTodoItem('Lateral Raises');
                addTodoItem('Front Raises');
                addTodoItem('Upright Rows');
                break;
            case 'arm-day':
                addTodoItem('Bicep Curls');
                addTodoItem('Tricep Extensions');
                addTodoItem('Hammer Curls');
                addTodoItem('Skull Crushers');
                break;
            default:
                break;
        }
    }

    function addTodoItem(task) {
        const li = document.createElement('li');
        li.innerHTML = `<input type="checkbox"> ${task}`;
        todoList.appendChild(li);
    }
});
